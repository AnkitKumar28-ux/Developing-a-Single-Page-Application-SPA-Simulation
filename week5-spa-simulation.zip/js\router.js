/**
 * ============================================================================
 * NexusFlow SPA — Client-Side Router (js/router.js)
 * ============================================================================
 * Responsibilities:
 * - Intercepts in-app navigation without full page reloads
 * - Manipulates browser history via window.history.pushState / replaceState
 * - Listens to popstate events for Back/Forward browser buttons
 * - Matches static & parameterized routes (e.g., /projects/:id)
 * - Orchestrates smooth CSS exit/enter transitions & error boundaries
 */

class SPARouter {
  constructor({ store, views, outletSelector, showToast }) {
    this.store = store;
    this.views = views;
    this.outlet = document.querySelector(outletSelector);
    this.showToast = showToast;
    this.currentPath = "/dashboard";
    this.currentViewKey = "dashboard";
    this.currentParams = {};
    this.navigationToken = 0;

    // Route table supporting static paths and dynamic :param segments
    this.routes = [
      { pattern: /^\/$/, redirect: "/dashboard" },
      { pattern: /^\/dashboard$/, viewKey: "dashboard" },
      { pattern: /^\/projects$/, viewKey: "projects" },
      { pattern: /^\/projects\/([^/]+)$/, viewKey: "projectDetail", paramNames: ["id"] },
      { pattern: /^\/tasks$/, viewKey: "tasks" },
      { pattern: /^\/analytics$/, viewKey: "analytics" },
      { pattern: /^\/architecture$/, viewKey: "architecture" }
    ];
  }

  /**
   * Extract normalized route path from URL hash or History API state
   */
  resolveLocationPath() {
    if (window.location.hash && window.location.hash.startsWith("#/")) {
      return window.location.hash.slice(1);
    }
    if (window.history.state && window.history.state.route) {
      return window.history.state.route;
    }
    return "/dashboard";
  }

  /**
   * Match a normalized path against the route table
   */
  matchRoute(rawPath) {
    const cleanPath = (rawPath || "/dashboard").split("?")[0].replace(/\/+$/, "") || "/";

    for (const route of this.routes) {
      const match = cleanPath.match(route.pattern);
      if (match) {
        if (route.redirect) {
          return this.matchRoute(route.redirect);
        }
        const params = {};
        if (route.paramNames) {
          route.paramNames.forEach((name, index) => {
            params[name] = decodeURIComponent(match[index + 1]);
          });
        }
        return {
          matched: true,
          path: cleanPath,
          viewKey: route.viewKey,
          params
        };
      }
    }

    return {
      matched: false,
      path: cleanPath,
      viewKey: "notFound",
      params: { unmatchedPath: cleanPath }
    };
  }

  /**
   * Navigate programmatically to a virtual route using History API
   */
  async navigate(targetPath, options = {}) {
    const { replace = false, trigger = replace ? "replaceState" : "pushState" } = options;
    const normalized = targetPath.startsWith("#") ? targetPath.slice(1) : targetPath;
    const routeMatch = this.matchRoute(normalized);

    const statePayload = {
      route: routeMatch.path,
      viewKey: routeMatch.viewKey,
      params: routeMatch.params,
      timestamp: Date.now()
    };

    // Manipulate Browser History via History API without triggering a page reload
    try {
      const urlWithHash = "#" + routeMatch.path;
      if (replace) {
        window.history.replaceState(statePayload, "", urlWithHash);
      } else if (window.location.hash !== urlWithHash) {
        window.history.pushState(statePayload, "", urlWithHash);
      }
    } catch (err) {
      // Fallback for restricted sandboxed environments
      window.location.hash = routeMatch.path;
    }

    await this.renderRoute(routeMatch, trigger);
  }

  /**
   * Perform asynchronous transition and DOM injection into #app-view
   */
  async renderRoute(routeMatch, trigger = "pushState") {
    const token = ++this.navigationToken;
    const progressEl = document.getElementById("route-progress");
    const state = this.store.getState();

    // 1. Start top progress indicator & exit transition
    if (progressEl) {
      progressEl.className = "route-progress active";
    }
    if (this.outlet) {
      this.outlet.classList.remove("view-enter");
      this.outlet.classList.add("view-exit");
    }

    // 2. Simulate configurable network latency if enabled
    const latency = state.simulatedLatencyMs || 0;
    if (latency > 0) {
      await new Promise((resolve) => setTimeout(resolve, latency));
    }

    // Abort if a newer navigation superseded this one (prevents race conditions)
    if (token !== this.navigationToken) return;

    const renderStart = performance.now();

    // 3. Check if user armed a simulated async error for testing Error Boundaries
    let activeViewKey = routeMatch.viewKey;
    let activeParams = routeMatch.params;

    if (this.store.consumeSimulatedError()) {
      activeViewKey = "errorBoundary";
      activeParams = {
        failedPath: routeMatch.path,
        errorMessage: "Simulated ERR_CHUNK_LOAD_TIMEOUT (503) during dynamic view fetch"
      };
    }

    const viewController = this.views[activeViewKey] || this.views.notFound;

    // Pre-record navigation so Analytics & Telemetry views include the current transition
    this.store.recordNavigation(
      {
        path: routeMatch.path,
        trigger,
        renderMs: state.telemetry.lastRenderMs || 1.2,
        params: activeParams
      },
      true
    );

    // 4. Render HTML into the SPA container
    try {
      this.currentPath = routeMatch.path;
      this.currentViewKey = activeViewKey;
      this.currentParams = activeParams;

      if (this.outlet) {
        this.outlet.innerHTML = viewController.render(this.store.getState(), activeParams);
        this.outlet.classList.remove("view-exit");
        // Force reflow so enter animation plays cleanly every time
        void this.outlet.offsetWidth;
        this.outlet.classList.add("view-enter");
      }

      // 5. Bind view-specific interactive listeners
      if (typeof viewController.afterRender === "function") {
        viewController.afterRender(this.store.getState(), activeParams, {
          showToast: this.showToast,
          navigate: (path, opts) => this.navigate(path, opts)
        });
      }
    } catch (renderError) {
      console.error("[Router] View render error:", renderError);
      if (this.outlet) {
        this.outlet.innerHTML = this.views.errorBoundary.render(this.store.getState(), {
          failedPath: routeMatch.path,
          errorMessage: renderError.message
        });
      }
    }

    const renderDuration = performance.now() - renderStart;
    this.store.getState().telemetry.lastRenderMs = renderDuration;
    if (this.store.getState().telemetry.historyLog[0]) {
      this.store.getState().telemetry.historyLog[0].renderMs = `${renderDuration.toFixed(1)} ms`;
    }

    // 6. Update document title, navigation active classes, and telemetry UI
    document.title = `${viewController.title} — NexusFlow SPA`;
    this.updateChromeUI(routeMatch.path, trigger, renderDuration);

    // Complete progress bar
    if (progressEl) {
      progressEl.className = "route-progress complete";
    }
  }

  /**
   * Re-render current view in-place when reactive store state mutates
   */
  refreshCurrentView() {
    const viewController = this.views[this.currentViewKey];
    if (!viewController || !this.outlet) return;

    const start = performance.now();
    this.outlet.innerHTML = viewController.render(this.store.getState(), this.currentParams);
    if (typeof viewController.afterRender === "function") {
      viewController.afterRender(this.store.getState(), this.currentParams, {
        showToast: this.showToast,
        navigate: (path, opts) => this.navigate(path, opts)
      });
    }
    const elapsed = performance.now() - start;
    const renderMetricEl = document.getElementById("render-time-metric");
    if (renderMetricEl) {
      renderMetricEl.textContent = `${elapsed.toFixed(1)} ms`;
    }
  }

  /**
   * Synchronize sidebar active states, route bar, and footer telemetry
   */
  updateChromeUI(path, trigger, renderDuration) {
    const baseSegment = "/" + (path.split("/").filter(Boolean)[0] || "dashboard");

    document.querySelectorAll(".nav-link").forEach((link) => {
      const linkRoute = link.getAttribute("data-route");
      if (linkRoute === baseSegment) {
        link.classList.add("active");
        link.setAttribute("aria-current", "page");
      } else {
        link.classList.remove("active");
        link.removeAttribute("aria-current");
      }
    });

    const routeDisplay = document.getElementById("current-route-display");
    if (routeDisplay) routeDisplay.textContent = path;

    const triggerBadge = document.getElementById("route-trigger-badge");
    if (triggerBadge) triggerBadge.textContent = trigger.toUpperCase();

    const historyPreview = document.getElementById("history-state-preview");
    if (historyPreview) {
      const stateObj = window.history.state || { route: path };
      historyPreview.textContent = JSON.stringify({
        route: stateObj.route || path,
        params: stateObj.params || {}
      });
    }

    const renderMetric = document.getElementById("render-time-metric");
    if (renderMetric) {
      renderMetric.textContent = `${renderDuration.toFixed(1)} ms`;
    }

    const transitionCounter = document.getElementById("transition-counter");
    if (transitionCounter) {
      transitionCounter.textContent = String(this.store.getState().telemetry.transitionCount);
    }
  }

  /**
   * Initialize global event delegation and History API listeners
   */
  init() {
    // 1. Intercept all clicks on elements with [data-link]
    document.addEventListener("click", (e) => {
      const link = e.target.closest("[data-link]");
      if (!link) return;

      e.preventDefault();
      const href = link.getAttribute("href") || "#/dashboard";
      const targetPath = href.startsWith("#") ? href.slice(1) : href;

      // Close mobile sidebar if open
      const sidebar = document.getElementById("sidebar");
      if (sidebar) sidebar.classList.remove("open");

      this.navigate(targetPath, { replace: false, trigger: "pushState" });
    });

    // 2. Listen to browser Back / Forward buttons via History API popstate
    window.addEventListener("popstate", (event) => {
      const targetPath =
        (event.state && event.state.route) || this.resolveLocationPath();
      const routeMatch = this.matchRoute(targetPath);
      this.renderRoute(routeMatch, "popstate");
    });

    // 3. Initial route resolution using replaceState
    const initialPath = this.resolveLocationPath();
    this.navigate(initialPath, { replace: true, trigger: "replaceState" });
  }
}

window.SPARouter = SPARouter;
