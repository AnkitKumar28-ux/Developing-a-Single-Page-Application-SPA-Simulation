/**
 * ============================================================================
 * NexusFlow SPA — Application Bootstrapper (js/app.js)
 * ============================================================================
 * Coordinates:
 * - Store initialization & reactive UI subscriptions
 * - Client-Side Router instantiation
 * - Global shell controls (History Back/Forward, Theme Toggle, Latency Slider,
 *   Error Simulation, Quick Search Navigation, and Toast Notifications)
 */

(function () {
  "use strict";

  /**
   * Display a non-blocking toast notification
   */
  function showToast(message) {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerHTML = `<span style="color:var(--accent-primary);">●</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateX(20px)";
      toast.style.transition = "all 200ms ease";
      setTimeout(() => toast.remove(), 220);
    }, 2600);
  }

  /**
   * Update sidebar counters and theme icon when state changes
   */
  function syncShellBadges(state) {
    const projectCountEl = document.getElementById("nav-project-count");
    if (projectCountEl) {
      projectCountEl.textContent = String(state.projects.length);
    }

    const pendingTasks = state.tasks.filter((t) => !t.completed).length;
    const taskCountEl = document.getElementById("nav-task-count");
    if (taskCountEl) {
      taskCountEl.textContent = String(pendingTasks);
    }

    const themeIconEl = document.getElementById("theme-icon");
    if (themeIconEl) {
      themeIconEl.textContent = state.theme === "dark" ? "☀️" : "🌙";
    }
  }

  /**
   * Bind global shell controls (Header & Sidebar)
   */
  function bindShellControls(store, router) {
    // 1. Browser History Back / Forward buttons
    const backBtn = document.getElementById("history-back-btn");
    const forwardBtn = document.getElementById("history-forward-btn");

    if (backBtn) {
      backBtn.addEventListener("click", () => {
        window.history.back();
      });
    }
    if (forwardBtn) {
      forwardBtn.addEventListener("click", () => {
        window.history.forward();
      });
    }

    // 2. Dark / Light Theme toggle
    const themeBtn = document.getElementById("theme-toggle-btn");
    if (themeBtn) {
      themeBtn.addEventListener("click", () => {
        const nextTheme = store.getState().theme === "dark" ? "light" : "dark";
        store.setTheme(nextTheme);
        showToast(`Switched to ${nextTheme} mode`);
      });
    }

    // 3. Simulated Network Latency Slider
    const latencySlider = document.getElementById("latency-slider");
    const latencyValue = document.getElementById("latency-value");
    if (latencySlider && latencyValue) {
      latencySlider.addEventListener("input", (e) => {
        const ms = Number(e.target.value);
        latencyValue.textContent = `${ms}ms`;
        store.setSimulatedLatency(ms);
      });
    }

    // 4. Simulate Async Route Error Button
    const simErrorBtn = document.getElementById("simulate-error-btn");
    if (simErrorBtn) {
      simErrorBtn.addEventListener("click", () => {
        store.armSimulatedError();
        showToast("Armed async route error boundary");
        router.navigate("/analytics", { replace: false, trigger: "pushState" });
      });
    }

    // 5. Global Quick Navigation Search
    const searchInput = document.getElementById("global-search");
    if (searchInput) {
      searchInput.addEventListener("keydown", (e) => {
        if (e.key !== "Enter") return;
        const query = searchInput.value.trim().toLowerCase();
        if (!query) return;

        const state = store.getState();
        const matchedProject = state.projects.find(
          (p) =>
            p.id.toLowerCase() === query ||
            p.name.toLowerCase().includes(query)
        );

        if (matchedProject) {
          router.navigate(`/projects/${matchedProject.id}`);
        } else if ("dashboard".includes(query)) {
          router.navigate("/dashboard");
        } else if ("projects".includes(query)) {
          router.navigate("/projects");
        } else if ("tasks".includes(query) || "board".includes(query)) {
          router.navigate("/tasks");
        } else if ("analytics".includes(query) || "metrics".includes(query)) {
          router.navigate("/analytics");
        } else if ("architecture".includes(query) || "telemetry".includes(query) || "history".includes(query)) {
          router.navigate("/architecture");
        } else {
          router.navigate(`/${encodeURIComponent(query)}`);
        }

        searchInput.value = "";
      });
    }

    // 6. Mobile Navigation Drawer Toggle
    const sidebar = document.getElementById("sidebar");
    const openMenuBtn = document.getElementById("mobile-menu-open");
    const closeMenuBtn = document.getElementById("mobile-menu-close");

    if (openMenuBtn && sidebar) {
      openMenuBtn.addEventListener("click", () => sidebar.classList.add("open"));
    }
    if (closeMenuBtn && sidebar) {
      closeMenuBtn.addEventListener("click", () => sidebar.classList.remove("open"));
    }
  }

  /**
   * Bootstrap Application on DOMContentLoaded
   */
  document.addEventListener("DOMContentLoaded", async () => {
    const store = window.appStore;
    const views = window.AppViews;

    // Apply persisted theme immediately
    document.documentElement.setAttribute("data-theme", store.getState().theme);

    // Initialize store data (fetches data/mock-data.json with file:// fallback)
    await store.init();
    syncShellBadges(store.getState());

    // Instantiate and initialize Client-Side Router
    const router = new window.SPARouter({
      store,
      views,
      outletSelector: "#app-view",
      showToast
    });

    // Subscribe to reactive store updates to refresh active view & badges
    store.subscribe((updatedState) => {
      syncShellBadges(updatedState);
      router.refreshCurrentView();
    });

    bindShellControls(store, router);
    router.init();
  });
})();
