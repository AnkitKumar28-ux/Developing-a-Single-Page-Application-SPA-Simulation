/**
 * ============================================================================
 * NexusFlow SPA — Dynamic View Templates & Controllers (js/views.js)
 * ============================================================================
 * Each view exports:
 * - title: Document title suffix
 * - render(state, params): Returns HTML string for the view container
 * - afterRender(state, params, helpers): Binds view-scoped interactive events
 */

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function getStatusBadgeClass(status) {
  switch (status) {
    case "Active":
      return "badge-info";
    case "Completed":
      return "badge-success";
    case "Review":
      return "badge-warning";
    default:
      return "badge-danger";
  }
}

function getPriorityBadgeClass(priority) {
  switch (priority) {
    case "High":
      return "badge-danger";
    case "Medium":
      return "badge-warning";
    default:
      return "badge-info";
  }
}

const Views = {
  /* ==========================================================================
     1. DASHBOARD VIEW (/dashboard)
     ========================================================================== */
  dashboard: {
    title: "Dashboard",
    render(state) {
      const totalProjects = state.projects.length;
      const avgProgress = totalProjects
        ? Math.round(state.projects.reduce((acc, p) => acc + p.progress, 0) / totalProjects)
        : 0;
      const completedTasks = state.tasks.filter((t) => t.completed).length;
      const pendingTasks = state.tasks.length - completedTasks;

      const topProjectsHtml = state.projects
        .slice(0, 3)
        .map(
          (p) => `
          <div class="card card-interactive">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.5rem;">
              <div>
                <span class="badge ${getStatusBadgeClass(p.status)}">${escapeHtml(p.status)}</span>
                <h3 style="margin-top:0.5rem; font-size:1.05rem;">${escapeHtml(p.name)}</h3>
              </div>
              <span style="font-weight:700; color:var(--accent-primary);">${p.progress}%</span>
            </div>
            <p style="color:var(--text-secondary); font-size:0.85rem; margin-bottom:0.8rem;">
              ${escapeHtml(p.description)}
            </p>
            <div class="progress-track">
              <div class="progress-fill" style="width:${p.progress}%"></div>
            </div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:0.75rem; font-size:0.8rem; color:var(--text-muted);">
              <span>Lead: ${escapeHtml(p.lead)}</span>
              <a href="#/projects/${encodeURIComponent(p.id)}" data-link class="btn btn-sm btn-secondary">
                Inspect →
              </a>
            </div>
          </div>
        `
        )
        .join("");

      const recentTasksHtml = state.tasks
        .slice(0, 4)
        .map(
          (t) => `
          <div class="task-item ${t.completed ? "completed" : ""}" style="padding:0.75rem 1rem;">
            <div class="task-left">
              <input type="checkbox" class="task-checkbox dash-task-toggle" data-task-id="${escapeHtml(t.id)}" ${
                t.completed ? "checked" : ""
              } aria-label="Toggle ${escapeHtml(t.title)}" />
              <span class="task-title" style="font-size:0.88rem;">${escapeHtml(t.title)}</span>
            </div>
            <span class="badge ${getPriorityBadgeClass(t.priority)}">${escapeHtml(t.priority)}</span>
          </div>
        `
        )
        .join("");

      return `
        <section aria-labelledby="dash-heading">
          <div class="view-header">
            <div>
              <h1 id="dash-heading" class="view-title">System Overview</h1>
              <p class="view-subtitle">
                Real-time Single Page Application workspace — zero full-page refreshes.
              </p>
            </div>
            <div style="display:flex; gap:0.65rem;">
              <a href="#/projects" data-link class="btn btn-secondary">Explore Projects</a>
              <a href="#/tasks" data-link class="btn btn-primary">+ Manage Tasks</a>
            </div>
          </div>

          <div class="stats-grid">
            <div class="card stat-card">
              <div class="stat-label">
                <span>Active Projects</span>
                <span class="badge badge-info">Portfolio</span>
              </div>
              <div class="stat-value">${totalProjects}</div>
              <div class="stat-trend trend-up">Avg. completion ${avgProgress}%</div>
            </div>

            <div class="card stat-card">
              <div class="stat-label">
                <span>Pending Tasks</span>
                <span class="badge badge-warning">Actionable</span>
              </div>
              <div class="stat-value">${pendingTasks}</div>
              <div class="stat-trend trend-neutral">${completedTasks} of ${state.tasks.length} completed</div>
            </div>

            <div class="card stat-card">
              <div class="stat-label">
                <span>SPA Route Transitions</span>
                <span class="badge badge-success">History API</span>
              </div>
              <div class="stat-value">${state.telemetry.transitionCount}</div>
              <div class="stat-trend trend-up">0 full-page reloads</div>
            </div>

            <div class="card stat-card">
              <div class="stat-label">
                <span>Last DOM Swap</span>
                <span class="badge badge-info">Latency</span>
              </div>
              <div class="stat-value">${state.telemetry.lastRenderMs.toFixed(1)}<small style="font-size:1rem;">ms</small></div>
              <div class="stat-trend trend-up">Source: ${escapeHtml(state.telemetry.dataSource)}</div>
            </div>
          </div>

          <div class="grid-2col">
            <div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                <h2 style="font-size:1.15rem;">Featured Engineering Projects</h2>
                <a href="#/projects" data-link style="font-size:0.85rem; color:var(--accent-primary); font-weight:600;">View All (${totalProjects}) →</a>
              </div>
              <div style="display:flex; flex-direction:column; gap:1rem;">
                ${topProjectsHtml}
              </div>
            </div>

            <div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
                <h2 style="font-size:1.15rem;">Quick Task Checklist</h2>
                <a href="#/tasks" data-link style="font-size:0.85rem; color:var(--accent-primary); font-weight:600;">Open Board →</a>
              </div>
              <div class="task-list">
                ${recentTasksHtml}
              </div>

              <div class="card" style="margin-top:1.25rem; background:linear-gradient(135deg, var(--bg-secondary), var(--bg-elevated));">
                <h3 style="font-size:0.98rem; margin-bottom:0.4rem;">How This SPA Works</h3>
                <p style="font-size:0.84rem; color:var(--text-secondary); margin-bottom:0.85rem;">
                  Clicking any navigation link intercepts the default browser request, updates the URL via
                  <code>history.pushState()</code>, and dynamically mounts the target template into <code>#app-view</code>.
                </p>
                <a href="#/architecture" data-link class="btn btn-sm btn-secondary">
                  Open Live History Inspector →
                </a>
              </div>
            </div>
          </div>
        </section>
      `;
    },
    afterRender(state, params, { showToast }) {
      document.querySelectorAll(".dash-task-toggle").forEach((checkbox) => {
        checkbox.addEventListener("change", (e) => {
          const id = e.target.getAttribute("data-task-id");
          window.appStore.toggleTask(id);
          showToast("Task status updated in reactive store");
        });
      });
    }
  },

  /* ==========================================================================
     2. PROJECTS EXPLORER VIEW (/projects)
     ========================================================================== */
  projects: {
    title: "Projects Explorer",
    render(state) {
      const categories = ["All", ...new Set(state.projects.map((p) => p.category))];
      const currentFilter = state.projectFilter || "All";

      const filteredProjects =
        currentFilter === "All"
          ? state.projects
          : state.projects.filter((p) => p.category === currentFilter);

      const tabsHtml = categories
        .map(
          (cat) => `
          <button type="button" class="tab-btn project-filter-btn ${
            cat === currentFilter ? "active" : ""
          }" data-category="${escapeHtml(cat)}">
            ${escapeHtml(cat)}
          </button>
        `
        )
        .join("");

      const cardsHtml = filteredProjects
        .map(
          (p) => `
          <article class="card card-interactive" style="display:flex; flex-direction:column; justify-content:space-between;">
            <div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.75rem;">
                <span class="badge ${getStatusBadgeClass(p.status)}">${escapeHtml(p.status)}</span>
                <span style="font-size:0.76rem; color:var(--text-muted); font-family:monospace;">${escapeHtml(p.id)}</span>
              </div>
              <h2 style="font-size:1.15rem; margin-bottom:0.35rem;">${escapeHtml(p.name)}</h2>
              <p style="font-size:0.8rem; color:var(--accent-primary); font-weight:600; margin-bottom:0.65rem;">
                ${escapeHtml(p.category)} • Lead: ${escapeHtml(p.lead)}
              </p>
              <p style="font-size:0.87rem; color:var(--text-secondary); margin-bottom:1rem;">
                ${escapeHtml(p.description)}
              </p>
            </div>

            <div>
              <div style="display:flex; justify-content:space-between; font-size:0.8rem; margin-bottom:0.25rem;">
                <span style="color:var(--text-secondary);">Milestone Progress</span>
                <strong>${p.progress}%</strong>
              </div>
              <div class="progress-track">
                <div class="progress-fill" style="width:${p.progress}%"></div>
              </div>
              <div style="display:flex; justify-content:space-between; align-items:center; margin-top:0.9rem;">
                <span style="font-size:0.76rem; color:var(--text-muted);">Updated ${escapeHtml(p.updatedAt)}</span>
                <a href="#/projects/${encodeURIComponent(p.id)}" data-link class="btn btn-sm btn-primary">
                  Open Details →
                </a>
              </div>
            </div>
          </article>
        `
        )
        .join("");

      return `
        <section aria-labelledby="projects-heading">
          <div class="view-header">
            <div>
              <h1 id="projects-heading" class="view-title">Projects Directory</h1>
              <p class="view-subtitle">
                Filter modules by domain or inspect parameterized routes (<code>/projects/:id</code>).
              </p>
            </div>
          </div>

          <div class="filter-bar">
            <div class="tab-group" role="tablist" aria-label="Filter projects by category">
              ${tabsHtml}
            </div>
            <span style="font-size:0.85rem; color:var(--text-secondary);">
              Showing <strong>${filteredProjects.length}</strong> of ${state.projects.length} projects
            </span>
          </div>

          <div class="projects-grid">
            ${cardsHtml}
          </div>
        </section>
      `;
    },
    afterRender() {
      document.querySelectorAll(".project-filter-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          const category = btn.getAttribute("data-category");
          window.appStore.setProjectFilter(category);
        });
      });
    }
  },

  /* ==========================================================================
     3. DYNAMIC PROJECT DETAIL VIEW (/projects/:id)
     ========================================================================== */
  projectDetail: {
    title: "Project Details",
    render(state, params) {
      const project = state.projects.find((p) => p.id === params.id);

      if (!project) {
        return `
          <div class="card error-state">
            <div class="error-code">404</div>
            <h1 class="view-title">Project Not Found</h1>
            <p class="view-subtitle" style="margin-bottom:1.5rem;">
              No project exists with route parameter <code>id = "${escapeHtml(params.id || "")}"</code>.
            </p>
            <a href="#/projects" data-link class="btn btn-primary">← Back to Projects</a>
          </div>
        `;
      }

      const metricEntries = Object.entries(project.metrics || {})
        .map(
          ([k, v]) => `
          <div class="card stat-card">
            <div class="stat-label" style="text-transform:capitalize;">${escapeHtml(k)}</div>
            <div class="stat-value" style="font-size:1.5rem;">${escapeHtml(v)}</div>
          </div>
        `
        )
        .join("");

      return `
        <section aria-labelledby="detail-heading">
          <div style="margin-bottom:1.25rem;">
            <a href="#/projects" data-link class="btn btn-sm btn-secondary">← Back to Projects</a>
          </div>

          <div class="card" style="margin-bottom:1.5rem;">
            <div class="view-header" style="margin-bottom:1rem;">
              <div>
                <div style="display:flex; gap:0.5rem; align-items:center; margin-bottom:0.5rem;">
                  <span class="badge ${getStatusBadgeClass(project.status)}">${escapeHtml(project.status)}</span>
                  <span class="badge badge-info">${escapeHtml(project.category)}</span>
                  <code style="font-size:0.78rem; color:var(--text-muted);">Route param: ${escapeHtml(project.id)}</code>
                </div>
                <h1 id="detail-heading" class="view-title">${escapeHtml(project.name)}</h1>
                <p class="view-subtitle">Lead Architect: <strong>${escapeHtml(project.lead)}</strong> • Last updated ${escapeHtml(project.updatedAt)}</p>
              </div>

              <div style="display:flex; gap:0.5rem;">
                <button type="button" id="dec-progress-btn" class="btn btn-secondary" data-id="${escapeHtml(project.id)}">
                  -5% Progress
                </button>
                <button type="button" id="inc-progress-btn" class="btn btn-primary" data-id="${escapeHtml(project.id)}">
                  +5% Progress
                </button>
              </div>
            </div>

            <p style="font-size:0.98rem; color:var(--text-secondary); margin-bottom:1.25rem;">
              ${escapeHtml(project.description)}
            </p>

            <div style="display:flex; justify-content:space-between; font-size:0.88rem; margin-bottom:0.35rem;">
              <span>Overall Completion</span>
              <strong>${project.progress}%</strong>
            </div>
            <div class="progress-track" style="height:12px;">
              <div class="progress-fill" style="width:${project.progress}%"></div>
            </div>
          </div>

          <h2 style="font-size:1.15rem; margin-bottom:1rem;">Live Telemetry & Service Metrics</h2>
          <div class="stats-grid">
            ${metricEntries}
          </div>
        </section>
      `;
    },
    afterRender(state, params, { showToast }) {
      const incBtn = document.getElementById("inc-progress-btn");
      const decBtn = document.getElementById("dec-progress-btn");

      if (incBtn) {
        incBtn.addEventListener("click", () => {
          window.appStore.advanceProjectProgress(params.id, 5);
          showToast(`Incremented ${params.id} progress (+5%)`);
        });
      }
      if (decBtn) {
        decBtn.addEventListener("click", () => {
          window.appStore.advanceProjectProgress(params.id, -5);
          showToast(`Decremented ${params.id} progress (-5%)`);
        });
      }
    }
  },

  /* ==========================================================================
     4. TASK BOARD VIEW (/tasks)
     ========================================================================== */
  tasks: {
    title: "Task Board",
    render(state) {
      const filter = state.taskFilter || "all";
      const filteredTasks = state.tasks.filter((t) => {
        if (filter === "pending") return !t.completed;
        if (filter === "completed") return t.completed;
        return true;
      });

      const taskItemsHtml =
        filteredTasks.length === 0
          ? `<div class="card" style="text-align:center; color:var(--text-secondary); padding:2.5rem;">
               No tasks match the selected filter (<strong>${escapeHtml(filter)}</strong>).
             </div>`
          : filteredTasks
              .map(
                (t) => `
              <div class="task-item ${t.completed ? "completed" : ""}">
                <div class="task-left">
                  <input
                    type="checkbox"
                    class="task-checkbox task-toggle"
                    data-id="${escapeHtml(t.id)}"
                    ${t.completed ? "checked" : ""}
                    aria-label="Mark ${escapeHtml(t.title)} as completed"
                  />
                  <div>
                    <div class="task-title" style="font-weight:500;">${escapeHtml(t.title)}</div>
                    <div style="font-size:0.76rem; color:var(--text-muted);">
                      Category: ${escapeHtml(t.category)} • ID: ${escapeHtml(t.id)}
                    </div>
                  </div>
                </div>
                <div style="display:flex; align-items:center; gap:0.65rem;">
                  <span class="badge ${getPriorityBadgeClass(t.priority)}">${escapeHtml(t.priority)}</span>
                  <button
                    type="button"
                    class="btn btn-sm btn-outline-danger task-delete"
                    data-id="${escapeHtml(t.id)}"
                    aria-label="Delete task"
                  >
                    Delete
                  </button>
                </div>
              </div>
            `
              )
              .join("");

      return `
        <section aria-labelledby="tasks-heading">
          <div class="view-header">
            <div>
              <h1 id="tasks-heading" class="view-title">Interactive Task Board</h1>
              <p class="view-subtitle">
                Create, toggle, and filter tasks with instant DOM updates and <code>localStorage</code> persistence.
              </p>
            </div>
          </div>

          <form id="new-task-form" class="card task-form" aria-label="Add new task">
            <input
              type="text"
              id="task-title-input"
              class="input-control"
              placeholder="Enter a new engineering task..."
              required
            />
            <select id="task-category-input" class="select-control" aria-label="Task category">
              <option value="Routing">Routing</option>
              <option value="State">State</option>
              <option value="UI/UX">UI/UX</option>
              <option value="QA">QA</option>
            </select>
            <select id="task-priority-input" class="select-control" aria-label="Task priority">
              <option value="High">High Priority</option>
              <option value="Medium" selected>Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>
            <button type="submit" class="btn btn-primary">+ Add Task</button>
          </form>

          <div class="filter-bar">
            <div class="tab-group" role="tablist">
              <button type="button" class="tab-btn task-filter-btn ${filter === "all" ? "active" : ""}" data-filter="all">
                All (${state.tasks.length})
              </button>
              <button type="button" class="tab-btn task-filter-btn ${filter === "pending" ? "active" : ""}" data-filter="pending">
                Pending (${state.tasks.filter((t) => !t.completed).length})
              </button>
              <button type="button" class="tab-btn task-filter-btn ${filter === "completed" ? "active" : ""}" data-filter="completed">
                Completed (${state.tasks.filter((t) => t.completed).length})
              </button>
            </div>
          </div>

          <div class="task-list">
            ${taskItemsHtml}
          </div>
        </section>
      `;
    },
    afterRender(state, params, { showToast }) {
      const form = document.getElementById("new-task-form");
      if (form) {
        form.addEventListener("submit", (e) => {
          e.preventDefault();
          const titleEl = document.getElementById("task-title-input");
          const categoryEl = document.getElementById("task-category-input");
          const priorityEl = document.getElementById("task-priority-input");

          const created = window.appStore.addTask({
            title: titleEl.value,
            category: categoryEl.value,
            priority: priorityEl.value
          });

          if (created) {
            titleEl.value = "";
            showToast(`Added task "${created.title}"`);
          }
        });
      }

      document.querySelectorAll(".task-toggle").forEach((checkbox) => {
        checkbox.addEventListener("change", () => {
          const id = checkbox.getAttribute("data-id");
          window.appStore.toggleTask(id);
          showToast("Task state updated");
        });
      });

      document.querySelectorAll(".task-delete").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-id");
          window.appStore.deleteTask(id);
          showToast("Task removed");
        });
      });

      document.querySelectorAll(".task-filter-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          window.appStore.setTaskFilter(btn.getAttribute("data-filter"));
        });
      });
    }
  },

  /* ==========================================================================
     5. ANALYTICS VIEW (/analytics)
     ========================================================================== */
  analytics: {
    title: "System Analytics",
    render(state) {
      const hits = state.analytics.routeHits || {};
      const maxHits = Math.max(1, ...Object.values(hits));

      const routeBarsHtml = Object.entries(hits)
        .map(([route, count]) => {
          const pct = Math.round((count / maxHits) * 100);
          return `
            <div class="bar-row">
              <code style="color:var(--accent-primary);">${escapeHtml(route)}</code>
              <div class="progress-track" style="margin:0;">
                <div class="progress-fill" style="width:${pct}%"></div>
              </div>
              <strong style="text-align:right;">${count} hits</strong>
            </div>
          `;
        })
        .join("");

      const perfComparisonHtml = (state.analytics.performanceSeries || [])
        .map((row) => {
          const speedup = (row.mpaMs / Math.max(1, row.spaMs)).toFixed(1);
          return `
            <tr>
              <td><strong>${escapeHtml(row.label)}</strong></td>
              <td><span class="badge badge-success">${row.spaMs} ms</span></td>
              <td><span class="badge badge-danger">${row.mpaMs} ms</span></td>
              <td><strong style="color:var(--accent-primary);">${speedup}x faster</strong></td>
            </tr>
          `;
        })
        .join("");

      return `
        <section aria-labelledby="analytics-heading">
          <div class="view-header">
            <div>
              <h1 id="analytics-heading" class="view-title">Performance & Route Analytics</h1>
              <p class="view-subtitle">
                Live route popularity metrics and empirical SPA vs. Multi-Page Application (MPA) latency benchmarks.
              </p>
            </div>
          </div>

          <div class="grid-2col">
            <div class="card">
              <h2 style="font-size:1.15rem; margin-bottom:0.4rem;">Route Navigation Frequency</h2>
              <p style="font-size:0.84rem; color:var(--text-secondary); margin-bottom:1.25rem;">
                Automatically increments as you navigate across views in this session.
              </p>
              <div class="chart-container">
                ${routeBarsHtml}
              </div>
            </div>

            <div class="card">
              <h2 style="font-size:1.15rem; margin-bottom:0.4rem;">SPA vs. Traditional MPA Latency</h2>
              <p style="font-size:0.84rem; color:var(--text-secondary); margin-bottom:1rem;">
                By avoiding full HTML/CSS/JS re-parsing and TCP handshakes, SPA transitions reduce navigation time by over 90%.
              </p>
              <table class="log-table">
                <thead>
                  <tr>
                    <th>Operation</th>
                    <th>SPA (DOM Swap)</th>
                    <th>MPA (Full Reload)</th>
                    <th>Gain</th>
                  </tr>
                </thead>
                <tbody>
                  ${perfComparisonHtml}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      `;
    },
    afterRender() {}
  },

  /* ==========================================================================
     6. SPA TELEMETRY & ARCHITECTURE VIEW (/architecture)
     ========================================================================== */
  architecture: {
    title: "SPA Telemetry & History Inspector",
    render(state) {
      const currentHistoryState = JSON.stringify(window.history.state || { route: "/architecture" }, null, 2);

      const historyRowsHtml =
        state.telemetry.historyLog.length === 0
          ? `<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">No transitions recorded yet.</td></tr>`
          : state.telemetry.historyLog
              .map(
                (entry) => `
              <tr>
                <td>#${entry.id}</td>
                <td><code>${escapeHtml(entry.timestamp)}</code></td>
                <td><strong style="color:var(--accent-primary);">${escapeHtml(entry.path)}</strong></td>
                <td><span class="badge badge-info">${escapeHtml(entry.trigger)}</span></td>
                <td><code>${escapeHtml(entry.renderMs)}</code></td>
              </tr>
            `
              )
              .join("");

      return `
        <section aria-labelledby="arch-heading">
          <div class="view-header">
            <div>
              <h1 id="arch-heading" class="view-title">SPA Telemetry & History API Inspector</h1>
              <p class="view-subtitle">
                Inspect live <code>window.history.state</code> payloads, router lifecycle events, and persisted store state.
              </p>
            </div>
            <button type="button" id="reset-store-btn" class="btn btn-outline-danger">
              Reset Persisted Store Data
            </button>
          </div>

          <div class="grid-2col" style="margin-bottom:1.5rem;">
            <div class="card">
              <h2 style="font-size:1.1rem; margin-bottom:0.65rem;">Current <code>window.history.state</code></h2>
              <pre class="code-panel">${escapeHtml(currentHistoryState)}</pre>
              <div style="margin-top:0.9rem; font-size:0.83rem; color:var(--text-secondary);">
                <strong>Browser History Stack Length:</strong> <code>window.history.length = ${window.history.length}</code>
              </div>
            </div>

            <div class="card">
              <h2 style="font-size:1.1rem; margin-bottom:0.65rem;">Router Architecture Summary</h2>
              <ul style="padding-left:1.2rem; color:var(--text-secondary); font-size:0.87rem; display:flex; flex-direction:column; gap:0.5rem;">
                <li><strong>Link Interception:</strong> Global event delegation captures clicks on <code>[data-link]</code> anchors and calls <code>event.preventDefault()</code>.</li>
                <li><strong>History Manipulation:</strong> Uses <code>history.pushState(stateObj, "", "#/path")</code> so URL updates work identically on HTTP servers and <code>file://</code> archives.</li>
                <li><strong>Popstate Listener:</strong> Handles browser Back/Forward buttons via <code>window.addEventListener("popstate", ...)</code>.</li>
                <li><strong>Race-Condition Protection:</strong> Monotonic navigation tokens cancel stale async renders if the user clicks rapidly.</li>
              </ul>
            </div>
          </div>

          <div class="card">
            <h2 style="font-size:1.1rem; margin-bottom:0.85rem;">Session Navigation Log (Zero Page Reloads)</h2>
            <div style="overflow-x:auto;">
              <table class="log-table">
                <thead>
                  <tr>
                    <th>Seq</th>
                    <th>Timestamp</th>
                    <th>Virtual Route</th>
                    <th>History Trigger</th>
                    <th>DOM Swap Time</th>
                  </tr>
                </thead>
                <tbody>
                  ${historyRowsHtml}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      `;
    },
    afterRender(state, params, { showToast }) {
      const resetBtn = document.getElementById("reset-store-btn");
      if (resetBtn) {
        resetBtn.addEventListener("click", () => {
          window.appStore.resetDemoData();
          showToast("Store reset to default mock dataset");
        });
      }
    }
  },

  /* ==========================================================================
     7. 404 NOT FOUND & ASYNC ERROR VIEWS
     ========================================================================== */
  notFound: {
    title: "404 — Route Not Found",
    render(state, params) {
      return `
        <section class="card error-state" aria-labelledby="err-404-title">
          <div class="error-code">404</div>
          <h1 id="err-404-title" class="view-title">Route Not Found</h1>
          <p class="view-subtitle" style="margin-bottom:1.25rem;">
            The client-side router could not match virtual path
            <code>${escapeHtml(params.unmatchedPath || window.location.hash)}</code> to any registered view controller.
          </p>
          <div class="code-panel" style="text-align:left; margin-bottom:1.5rem;">
            <div><strong>Router Diagnostic:</strong> No route pattern matched</div>
            <div><strong>Fallback Action:</strong> Rendered 404 Error Boundary without reloading page</div>
          </div>
          <div style="display:flex; justify-content:center; gap:0.75rem;">
            <a href="#/dashboard" data-link class="btn btn-primary">Return to Dashboard</a>
            <a href="#/architecture" data-link class="btn btn-secondary">Inspect Router Logs</a>
          </div>
        </section>
      `;
    },
    afterRender() {}
  },

  errorBoundary: {
    title: "Async Load Error",
    render(state, params) {
      return `
        <section class="card error-state" aria-labelledby="err-boundary-title">
          <div class="error-code">503</div>
          <h1 id="err-boundary-title" class="view-title">Simulated Asynchronous Load Failure</h1>
          <p class="view-subtitle" style="margin-bottom:1.25rem;">
            The SPA Error Boundary caught a simulated exception while loading
            <code>${escapeHtml(params.failedPath || "/unknown")}</code>:
          </p>
          <div class="code-panel" style="text-align:left; margin-bottom:1.5rem; color:var(--danger);">
            Error: ${escapeHtml(params.errorMessage || "Network timeout while fetching view chunk")}
          </div>
          <div style="display:flex; justify-content:center; gap:0.75rem;">
            <button type="button" id="retry-route-btn" class="btn btn-primary">Retry Route Load</button>
            <a href="#/dashboard" data-link class="btn btn-secondary">Safe Recovery (Dashboard)</a>
          </div>
        </section>
      `;
    },
    afterRender(state, params, { navigate }) {
      const retryBtn = document.getElementById("retry-route-btn");
      if (retryBtn) {
        retryBtn.addEventListener("click", () => {
          navigate(params.failedPath || "/dashboard", { replace: true });
        });
      }
    }
  }
};

window.AppViews = Views;
