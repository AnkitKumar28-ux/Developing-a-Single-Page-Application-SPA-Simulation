/**
 * ============================================================================
 * NexusFlow SPA — Reactive State Store (js/store.js)
 * ============================================================================
 * Implements a centralized Publish/Subscribe state container with:
 * - Asynchronous initialization from data/mock-data.json (with file:// fallback)
 * - Automatic persistence to window.localStorage
 * - Immutability-friendly state updates & telemetry logging
 */

const FALLBACK_DATA = {
  projects: [
    {
      id: "prj-101",
      name: "Quantum Edge CDN",
      category: "Infrastructure",
      status: "Active",
      progress: 84,
      lead: "Aria Chen",
      updatedAt: "2 hours ago",
      description: "Distributed edge caching layer with real-time invalidation and zero-downtime routing across 32 global PoPs.",
      metrics: { uptime: "99.99%", latency: "14ms", requests: "2.4M/min" }
    },
    {
      id: "prj-102",
      name: "Hyperion SPA Micro-Kernel",
      category: "Frontend",
      status: "Active",
      progress: 92,
      lead: "Marcus Vance",
      updatedAt: "25 mins ago",
      description: "Zero-dependency client-side router and virtual state synchronizer using native History API and CSS View Transitions.",
      metrics: { bundleSize: "4.2 KB", renderTime: "1.8ms", coverage: "96%" }
    },
    {
      id: "prj-103",
      name: "Sentinel Auth Gateway",
      category: "Security",
      status: "Review",
      progress: 68,
      lead: "Elena Rostova",
      updatedAt: "1 day ago",
      description: "Token-based OAuth2 & WebAuthn passkey authentication service with automatic session rotation.",
      metrics: { uptime: "99.95%", latency: "22ms", requests: "890K/min" }
    },
    {
      id: "prj-104",
      name: "Pulse Telemetry Pipeline",
      category: "Data Engineering",
      status: "Active",
      progress: 76,
      lead: "Devon Brooks",
      updatedAt: "4 hours ago",
      description: "High-throughput client performance observability collector tracking Core Web Vitals and SPA route transitions.",
      metrics: { uptime: "99.98%", latency: "9ms", requests: "5.1M/min" }
    },
    {
      id: "prj-105",
      name: "Atlas Design System v4",
      category: "UI/UX",
      status: "Completed",
      progress: 100,
      lead: "Sora Takahashi",
      updatedAt: "3 days ago",
      description: "Accessible WCAG-AAA compliant component tokens with adaptive dark/light themes and reduced-motion support.",
      metrics: { components: "48", a11yScore: "100/100", adoption: "94%" }
    },
    {
      id: "prj-106",
      name: "Nebula Graph Query Engine",
      category: "Backend",
      status: "Planning",
      progress: 35,
      lead: "Liam O'Connor",
      updatedAt: "5 hours ago",
      description: "Federated graph query planner optimizing multi-service data fetching for single-page applications.",
      metrics: { cacheHit: "88%", latency: "19ms", nodes: "12" }
    }
  ],
  tasks: [
    {
      id: "tsk-1",
      title: "Implement History API pushState and popstate listener",
      priority: "High",
      category: "Routing",
      completed: true
    },
    {
      id: "tsk-2",
      title: "Design responsive CSS grid shell with smooth view transitions",
      priority: "High",
      category: "UI/UX",
      completed: true
    },
    {
      id: "tsk-3",
      title: "Add dynamic route parameter parsing for /projects/:id",
      priority: "Medium",
      category: "Routing",
      completed: true
    },
    {
      id: "tsk-4",
      title: "Build reactive Pub/Sub store with localStorage persistence",
      priority: "High",
      category: "State",
      completed: false
    },
    {
      id: "tsk-5",
      title: "Verify 404 fallback view and asynchronous error boundaries",
      priority: "Medium",
      category: "QA",
      completed: false
    }
  ],
  analytics: {
    routeHits: {
      "/dashboard": 42,
      "/projects": 31,
      "/tasks": 27,
      "/analytics": 19,
      "/architecture": 14
    },
    performanceSeries: [
      { label: "Initial Shell Load", spaMs: 45, mpaMs: 620 },
      { label: "Dashboard → Projects", spaMs: 12, mpaMs: 540 },
      { label: "Projects → Detail View", spaMs: 8, mpaMs: 510 },
      { label: "Task State Mutation", spaMs: 4, mpaMs: 480 },
      { label: "History Back (popstate)", spaMs: 6, mpaMs: 490 }
    ]
  }
};

const STORAGE_KEY = "nexusflow_spa_state_v1";

class Store {
  constructor() {
    this.listeners = new Set();
    this.state = {
      initialized: false,
      theme: localStorage.getItem("nexusflow_theme") || "dark",
      simulatedLatencyMs: 180,
      simulateErrorNext: false,
      projectFilter: "All",
      taskFilter: "all",
      projects: [],
      tasks: [],
      analytics: { routeHits: {}, performanceSeries: [] },
      telemetry: {
        transitionCount: 0,
        lastRenderMs: 0,
        dataSource: "pending",
        historyLog: []
      }
    };
  }

  /**
   * Initialize store by fetching external JSON or restoring persisted state
   */
  async init() {
    if (this.state.initialized) return;

    let baseData = FALLBACK_DATA;
    let source = "embedded-fallback";

    try {
      const response = await fetch("data/mock-data.json", { cache: "no-store" });
      if (response.ok) {
        baseData = await response.json();
        source = "fetch(data/mock-data.json)";
      }
    } catch (_) {
      // Running via file:// protocol where CORS blocks local fetch; fallback is seamless
      source = "embedded-fallback (file:// safe)";
    }

    // Check localStorage for persisted user edits
    let saved = null;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) saved = JSON.parse(raw);
    } catch (_) {
      saved = null;
    }

    this.state.projects = (saved && saved.projects) ? saved.projects : baseData.projects;
    this.state.tasks = (saved && saved.tasks) ? saved.tasks : baseData.tasks;
    this.state.analytics = (saved && saved.analytics) ? saved.analytics : baseData.analytics;
    this.state.telemetry.dataSource = source;
    this.state.initialized = true;

    this.persist();
    this.notify();
  }

  getState() {
    return this.state;
  }

  subscribe(listener) {
    this.listeners.add(listener);
    this.updateListenerMetric();
    return () => {
      this.listeners.delete(listener);
      this.updateListenerMetric();
    };
  }

  updateListenerMetric() {
    const el = document.getElementById("store-listeners-metric");
    if (el) el.textContent = String(this.listeners.size);
  }

  notify() {
    this.updateListenerMetric();
    this.listeners.forEach((listener) => {
      try {
        listener(this.state);
      } catch (err) {
        console.error("[Store] Listener error:", err);
      }
    });
  }

  persist() {
    try {
      const payload = {
        projects: this.state.projects,
        tasks: this.state.tasks,
        analytics: this.state.analytics
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (err) {
      console.warn("[Store] Could not persist state to localStorage:", err);
    }
  }

  /* ==========================================================================
     State Actions / Mutations
     ========================================================================== */

  setTheme(theme) {
    this.state.theme = theme;
    localStorage.setItem("nexusflow_theme", theme);
    document.documentElement.setAttribute("data-theme", theme);
    this.notify();
  }

  setSimulatedLatency(ms) {
    this.state.simulatedLatencyMs = Number(ms) || 0;
  }

  armSimulatedError() {
    this.state.simulateErrorNext = true;
  }

  consumeSimulatedError() {
    if (this.state.simulateErrorNext) {
      this.state.simulateErrorNext = false;
      return true;
    }
    return false;
  }

  setProjectFilter(category) {
    this.state.projectFilter = category;
    this.notify();
  }

  setTaskFilter(filter) {
    this.state.taskFilter = filter;
    this.notify();
  }

  addTask({ title, priority, category }) {
    const cleanTitle = String(title || "").trim();
    if (!cleanTitle) return null;

    const newTask = {
      id: "tsk-" + Date.now().toString(36),
      title: cleanTitle,
      priority: priority || "Medium",
      category: category || "General",
      completed: false
    };

    this.state.tasks = [newTask, ...this.state.tasks];
    this.persist();
    this.notify();
    return newTask;
  }

  toggleTask(taskId) {
    this.state.tasks = this.state.tasks.map((task) =>
      task.id === taskId ? { ...task, completed: !task.completed } : task
    );
    this.persist();
    this.notify();
  }

  deleteTask(taskId) {
    this.state.tasks = this.state.tasks.filter((task) => task.id !== taskId);
    this.persist();
    this.notify();
  }

  advanceProjectProgress(projectId, delta = 5) {
    this.state.projects = this.state.projects.map((p) => {
      if (p.id !== projectId) return p;
      const nextProgress = Math.min(100, Math.max(0, p.progress + delta));
      const nextStatus = nextProgress === 100 ? "Completed" : p.status === "Completed" ? "Active" : p.status;
      return {
        ...p,
        progress: nextProgress,
        status: nextStatus,
        updatedAt: "Just now"
      };
    });
    this.persist();
    this.notify();
  }

  recordNavigation({ path, trigger, renderMs, params }, silent = true) {
    this.state.telemetry.transitionCount += 1;
    this.state.telemetry.lastRenderMs = renderMs;

    // Increment route hits counter
    const baseRoute = "/" + (path.split("/").filter(Boolean)[0] || "dashboard");
    if (this.state.analytics.routeHits[baseRoute] !== undefined) {
      this.state.analytics.routeHits[baseRoute] += 1;
    } else {
      this.state.analytics.routeHits[baseRoute] = 1;
    }

    const entry = {
      id: this.state.telemetry.transitionCount,
      timestamp: new Date().toLocaleTimeString(),
      path,
      trigger,
      renderMs: `${renderMs.toFixed(1)} ms`,
      params: JSON.stringify(params || {})
    };

    this.state.telemetry.historyLog = [
      entry,
      ...this.state.telemetry.historyLog.slice(0, 19)
    ];

    this.persist();
    if (!silent) {
      this.notify();
    }
  }

  resetDemoData() {
    localStorage.removeItem(STORAGE_KEY);
    this.state.projects = JSON.parse(JSON.stringify(FALLBACK_DATA.projects));
    this.state.tasks = JSON.parse(JSON.stringify(FALLBACK_DATA.tasks));
    this.state.analytics = JSON.parse(JSON.stringify(FALLBACK_DATA.analytics));
    this.persist();
    this.notify();
  }
}

window.appStore = new Store();
